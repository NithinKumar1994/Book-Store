/**
 * Enum class to define constants medium of the book.
 */
public enum Medium {
    Paperback,
    Hardcover,
    Audio,
    Electronic
}
